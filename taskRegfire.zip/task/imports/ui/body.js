import { Template } from 'meteor/templating';

 
import './body.html';
 
import { Mongo } from 'meteor/mongo';
 
info = new Mongo.Collection('info');

Template.info.helpers({
  info: function() {
    return info.find({}, {sort: {createdAt : -1}});
  },
});

Template.body.events({
  'submit .new-stu'(event) {
   
    event.preventDefault();
 
    const target = event.target;
    var name = target.name.value;
    var email = target.email.value;
    var phone = target.phone.value;
    var dob = target.dob.value;
    console.log(name);
    console.log(email);
    console.log(phone);
    console.log(dob);
 
    info.insert({
      Name: name,
      Email: email,
      Phone: phone,
      DOB: dob,
      createdAt: new Date(),
    });
 
    target.text.value = '';
    target.email.value = '';
    target.phone.value = '';
    target.dob.value = '';

    return false;
    
  },
});