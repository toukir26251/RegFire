import { Meteor } from 'meteor/meteor';

//import '../imports/api/task.js';

Meteor.startup(() => {
	const info = new Mongo.Collection('info');
  // code to run on server at startup
});
